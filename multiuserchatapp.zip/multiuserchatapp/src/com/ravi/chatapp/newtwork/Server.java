package com.ravi.chatapp.newtwork;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.ravi.chatapp.utils.ConfigReader;

public class Server {

	ArrayList<ServerWorker> workers=new ArrayList<>();
	ServerSocket serverSocket;
	public Server() throws IOException {
		int PORT=Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket=new ServerSocket(PORT);
		System.out.println("Server started And Waiting For Client to Join....");
		handleClientRequest();
	
	
	}
	public void handleClientRequest() throws IOException{
		while(true) {
			Socket clientSocket=serverSocket.accept();
			ServerWorker serverWorker=new ServerWorker(clientSocket,this);
			workers.add(serverWorker);
			serverWorker.start();
		}
	}
	/*public Server() throws IOException {
	int PORT=Integer.parseInt(ConfigReader.getValue("PORTNO"));
	serverSocket=new ServerSocket(PORT);
	System.out.println("Server Started and waiting client Connection..");
	Socket socket=serverSocket.accept();
	System.out.println("Client attached");
	InputStream in=socket.getInputStream();
	byte[] arr=in.readAllBytes();
	String str=new String(arr);
	System.out.println("Message recievd" + str);
	in.close();
	socket.close();*/
	public static void main(String[] args) throws IOException {
	Server server=new Server();

	}

}
