package com.ravi.chatapp.veiws;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class UserVeiws extends JFrame {

	int count;

	public UserVeiws() {
		count = 0;
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Login");
		setSize(400, 400);
		setLocationRelativeTo(null);

		JLabel welcome = new JLabel("Login");
		welcome.setFont(new Font("Arial", Font.BOLD, 40));
		Container container = this.getContentPane();
		container.setLayout(null);
		welcome.setBounds(100, 70, 200, 60);
		container.add(welcome);
		JButton button = new JButton("count");
		button.setBounds(100, 70, 200, 60);
		container.add(button);
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				count++;
				welcome.setText("Count" + count);

			}
		});

		setVisible(true);

	}

	public static void main(String[] args) {
		UserVeiws userVeiws = new UserVeiws();

	}
}
