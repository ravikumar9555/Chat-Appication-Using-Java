package com.ravi.chatapp.veiws;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import com.ravi.chatapp.dao.UserDao;
import com.ravi.chatapp.dto.UserDto;
import com.ravi.chatapp.utils.UserInfo;

import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UserScreen extends JFrame {
	private JPasswordField passwordField;
	private JTextField useridtxt;

	public static void main(String[] args) {

		UserScreen window = new UserScreen();

	}
	UserDao userDao=new UserDao();
	public void doLogin() {
		String userid=useridtxt.getText();
		char[] password=passwordField.getPassword();
		
		UserDto userDto=new UserDto(userid, password);
		
		String message="";
		try {
			if(userDao.isLogin(userDto)) {
				message="Welcome "+userid;
				UserInfo.USER_NAME=userid;
				JOptionPane.showMessageDialog(this, message);
				setVisible(false);
				dispose();
				HomeDashBoard homeDashBoard=new HomeDashBoard(message);
			     homeDashBoard.setVisible(true);
			}else {
				message="Invalid Userid and Password";
				JOptionPane.showMessageDialog(this, message);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void register() throws ClassNotFoundException,SQLException {
		String userid=useridtxt.getText();
		char[] password=passwordField.getPassword();
		
		UserDto userDto=new UserDto(userid, password);
		try {
		int result=userDao.add(userDto);
		if(result>0) {
			JOptionPane.showMessageDialog(this, "Registered Successfully!");
		}else {
			JOptionPane.showMessageDialog(this, "Registerd Fail !");
		}
		}catch(ClassNotFoundException|SQLException ex) {
			System.out.println("error");
			ex.printStackTrace();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		System.out.println("userid" + userid + "password " + password);
	}

	public UserScreen() {
		setResizable(false);
		setTitle("LOGIN");
		getContentPane().setBackground(new Color(255, 255, 255));
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(210, 37, 193, 88);
		getContentPane().add(lblNewLabel);

		JLabel useridlbl = new JLabel("UserId");
		useridlbl.setFont(new Font("Tahoma", Font.BOLD, 18));
		useridlbl.setBounds(179, 170, 150, 37);
		getContentPane().add(useridlbl);

		JLabel pwdlbl = new JLabel("Password");
		pwdlbl.setFont(new Font("Tahoma", Font.BOLD, 18));
		pwdlbl.setBounds(179, 232, 150, 37);
		getContentPane().add(pwdlbl);

		passwordField = new JPasswordField();
		passwordField.setBounds(387, 232, 265, 31);
		getContentPane().add(passwordField);

		useridtxt = new JTextField();
		useridtxt.setBounds(385, 170, 267, 37);
		getContentPane().add(useridtxt);
		useridtxt.setColumns(10);

		JButton loginbt = new JButton("Login");
		loginbt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doLogin();
			}
		});
		loginbt.setFont(new Font("Tahoma", Font.PLAIN, 16));
		loginbt.setBounds(312, 314, 91, 31);
		getContentPane().add(loginbt);

		JButton registerbt = new JButton("Register");
		registerbt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					register();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}}
		});
		registerbt.setFont(new Font("Tahoma", Font.PLAIN, 16));
		registerbt.setBounds(417, 314, 134, 31);
		getContentPane().add(registerbt);

		setSize(787, 458);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	

	}
}
