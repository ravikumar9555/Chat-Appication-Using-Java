package com.ravi.chatapp.dao;

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ravi.chatapp.dto.UserDto;
import com.ravi.chatapp.utils.Encryption;

public class UserDao {

	public boolean isLogin (UserDto userDto) throws SQLException, ClassNotFoundException, NoSuchAlgorithmException,Exception {
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		final String SQL="select userid from users where userid=? and password=?";
		try {
			con=CommanDao.createConnection();
			pstmt=con.prepareStatement(SQL);
			pstmt.setString(1, userDto.getUserid());
			String encryptPwd=Encryption.passwordEncrypt(new String(userDto.getPassword()));
		pstmt.setString(2, encryptPwd);
		rs=pstmt.executeQuery();
		return rs.next();
		}
		
		finally {
			if(rs!=null) {
				rs.close();
			}
			if(pstmt!=null) {
				pstmt.close();
			}
			if(con!=null) {
				con.close();
			}
		}
		
	}
	public int add(UserDto userDto) throws ClassNotFoundException,SQLException ,Exception{
		System.out.println(" " +userDto.getUserid()+" " + userDto.getPassword() );
		Connection connection=null;
		Statement stmt=null;
		try {
		connection=CommanDao.createConnection();
		stmt=connection.createStatement();
		//insert into users (userid, password) values('ram','ram123');
		int record=stmt.executeUpdate("insert into users (userid,password) values ( '" + userDto.getUserid()+"','"+Encryption.passwordEncrypt(new  String(userDto.getPassword()))+"')");
		return record;
		}finally {
			if(stmt!=null) {
				stmt.close();
			}
			if(connection!=null) {
				connection.close();
			}
		}

	}
}
